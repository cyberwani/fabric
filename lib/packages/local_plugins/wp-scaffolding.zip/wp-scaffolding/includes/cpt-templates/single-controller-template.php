<?php
/**
 * =======================================
 * Single %1$s Controller
 * =======================================
 */

namespace Fabric\Controllers;

class Single%1$s extends Single
{

	public function __construct()
	{
		parent::__construct();
	}

}