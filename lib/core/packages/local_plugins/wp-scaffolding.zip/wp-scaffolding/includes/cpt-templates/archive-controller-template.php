<?php
/**
 * =======================================
 * %1$s Archive Controller
 * =======================================
 */

namespace Fabric\Controllers;

class Archive%1$s extends Archive
{

	public function __construct()
	{
		parent::__construct();
	}

}